[
	{
      "name": "SPACE RP #1",
	  "color": "ff33AAD9",
	  "status": 0,
	  "recommend": true,
	  "newstatus": false,
      "edgar_host": "SPACE-RP",
      "edgar_port": 7777,
      "id": 0
	}
]